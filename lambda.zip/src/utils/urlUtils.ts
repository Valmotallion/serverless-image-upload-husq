import { APIGatewayProxyEvent } from 'aws-lambda';

/**
 * Resolves the base URL for the API from environment variable or event context
 * @param event - The API Gateway event
 * @returns The base URL for the API
 */
export const resolveBaseUrl = (event: APIGatewayProxyEvent): string => {
  // Prefer BASE_URL environment variable if set
  const envBaseUrl = process.env.BASE_URL;
  if (envBaseUrl) {
    return envBaseUrl.endsWith('/') ? envBaseUrl.slice(0, -1) : envBaseUrl;
  }

  // Fall back to deriving from event context
  const { domainName, stage } = event.requestContext;
  
  if (!domainName) {
    throw new Error('Unable to determine domain name from event context');
  }
  
  // Handle different deployment scenarios
  if (domainName.includes('lambda-url')) {
    // Lambda Function URL format
    return `https://${domainName}`;
  } else {
    // API Gateway format
    return `https://${domainName}/${stage}`;
  }
};

/**
 * Generates a full retrieval URL for an image
 * @param event - The API Gateway event
 * @param imageId - The image ID
 * @returns The full URL for retrieving the image
 */
export const generateImageUrl = (event: APIGatewayProxyEvent, imageId: string): string => {
  const baseUrl = resolveBaseUrl(event);
  return `${baseUrl}/image/${imageId}`;
};
