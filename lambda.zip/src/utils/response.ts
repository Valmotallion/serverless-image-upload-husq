import { ApiResponse } from '../types';

export const createResponse = (
  statusCode: number,
  body: any,
  headers: Record<string, string> = {},
  isBase64Encoded: boolean = false
): ApiResponse => {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      ...headers
    },
    body: typeof body === 'string' ? body : JSON.stringify(body),
    isBase64Encoded
  };
};

export const successResponse = (body: any, headers?: Record<string, string>): ApiResponse => {
  return createResponse(200, body, headers);
};

export const createdResponse = (body: any, headers?: Record<string, string>): ApiResponse => {
  return createResponse(201, body, headers);
};

export const notFoundResponse = (message: string = 'Resource not found'): ApiResponse => {
  return createResponse(404, { error: message });
};

export const badRequestResponse = (message: string): ApiResponse => {
  return createResponse(400, { error: message });
};

export const internalErrorResponse = (message: string = 'Internal server error'): ApiResponse => {
  return createResponse(500, { error: message });
};

export const binaryResponse = (body: Buffer, contentType: string): ApiResponse => {
  return {
    statusCode: 200,
    headers: {
      'Content-Type': contentType,
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'max-age=3600'
    },
    body: body.toString('base64'),
    isBase64Encoded: true
  };
};
