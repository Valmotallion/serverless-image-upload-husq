import { APIGatewayProxyEvent, Context, APIGatewayProxyResult } from 'aws-lambda';
import { Router } from '../services/router';
import { S3Service } from '../services/s3Service';
import { DbService } from '../services/dbService';
import { 
  successResponse, 
  createdResponse,
  notFoundResponse, 
  badRequestResponse, 
  internalErrorResponse,
  binaryResponse
} from '../utils/response';
import { generateImageUrl } from '../utils/urlUtils';
import { v4 as uuidv4 } from 'uuid';

// Types for Lambda Function URL events
interface LambdaFunctionUrlEvent {
  version: string;
  routeKey: string;
  rawPath: string;
  rawQueryString: string;
  headers: { [key: string]: string };
  requestContext: {
    accountId: string;
    apiId: string;
    domainName: string;
    http: {
      method: string;
      path: string;
      protocol: string;
      sourceIp: string;
      userAgent: string;
    };
  };
  body?: string;
  isBase64Encoded: boolean;
}

// Services will be initialized lazily to allow for proper mocking
let s3Service: S3Service;
let dbService: DbService;
const router = new Router();

// Helper function to normalize Lambda Function URL events to API Gateway format
const normalizeEvent = (event: any): APIGatewayProxyEvent => {
  // If it's already an API Gateway event, return as is
  if (event.requestContext && event.requestContext.resourcePath) {
    return event as APIGatewayProxyEvent;
  }

  // Convert Lambda Function URL event to API Gateway format
  const path = event.rawPath || '/';
  const method = event.requestContext?.http?.method || 'GET';
  
  // Extract path parameters for routes like /image/{id}
  const pathParams: { [key: string]: string } = {};
  if (path.startsWith('/image/') && path !== '/image/') {
    const id = path.split('/')[2];
    pathParams.id = id;
  }

  return {
    resource: path,
    path: path,
    httpMethod: method,
    headers: event.headers || {},
    multiValueHeaders: {},
    queryStringParameters: null,
    multiValueQueryStringParameters: null,
    pathParameters: Object.keys(pathParams).length > 0 ? pathParams : null,
    stageVariables: null,
    requestContext: {
      resourceId: '',
      resourcePath: path,
      httpMethod: method,
      requestId: event.requestContext?.requestId || '',
      accountId: event.requestContext?.accountId || '',
      apiId: event.requestContext?.apiId || '',
      stage: 'prod',
      requestTimeEpoch: Date.now(),
      requestTime: new Date().toISOString(),
      identity: {
        cognitoIdentityPoolId: null,
        accountId: null,
        cognitoIdentityId: null,
        caller: null,
        sourceIp: event.requestContext?.http?.sourceIp || '',
        principalOrgId: null,
        accessKey: null,
        cognitoAuthenticationType: null,
        cognitoAuthenticationProvider: null,
        userArn: null,
        userAgent: event.requestContext?.http?.userAgent || '',
        user: null
      },
      protocol: event.requestContext?.http?.protocol || 'HTTP/1.1',
      domainName: event.requestContext?.domainName || ''
    },
    body: event.body || null,
    isBase64Encoded: event.isBase64Encoded || false
  } as APIGatewayProxyEvent;
};

// Helper functions to get service instances
const getS3Service = (): S3Service => {
  if (!s3Service) {
    s3Service = new S3Service();
  }
  return s3Service;
};

const getDbService = (): DbService => {
  if (!dbService) {
    dbService = new DbService();
  }
  return dbService;
};

// Upload handler
const uploadHandler = async (event: APIGatewayProxyEvent, context: Context) => {
  try {
    if (!event.body) {
      return badRequestResponse('No image data provided');
    }

    const contentType = event.headers['Content-Type'] || event.headers['content-type'] || '';
    
    if (!contentType.startsWith('image/')) {
      return badRequestResponse('Content-Type must be an image type');
    }

    // Decode base64 body if necessary
    const imageBuffer = event.isBase64Encoded 
      ? Buffer.from(event.body, 'base64')
      : Buffer.from(event.body, 'binary');

    // Validate image size (max 10MB)
    if (imageBuffer.length > 10 * 1024 * 1024) {
      return badRequestResponse('Image size must be less than 10MB');
    }

    const imageId = uuidv4();
    const s3Key = await getS3Service().uploadImage(imageBuffer, contentType);
    await getDbService().saveImageMetadata(imageId, s3Key);

    const url = generateImageUrl(event, imageId);

    return createdResponse({
      imageId,
      url,
      message: 'Image uploaded successfully'
    });

  } catch (error: any) {
    console.error('Upload error:', error);
    return internalErrorResponse(`Upload failed: ${error.message}`);
  }
};

// Retrieve handler
const retrieveHandler = async (event: APIGatewayProxyEvent, context: Context) => {
  try {
    const imageId = event.pathParameters?.id;
    
    if (!imageId) {
      return badRequestResponse('Image ID is required');
    }

    const metadata = await getDbService().getImageMetadata(imageId);
    
    if (!metadata) {
      return notFoundResponse('Image not found');
    }

    const imageBuffer = await getS3Service().getImage(metadata.s3Key);
    const contentType = getS3Service().getContentTypeFromKey(metadata.s3Key);

    return binaryResponse(imageBuffer, contentType);

  } catch (error: any) {
    console.error('Retrieve error:', error);
    
    if (error.message.includes('not found')) {
      return notFoundResponse('Image not found');
    }
    
    return internalErrorResponse(`Retrieve failed: ${error.message}`);
  }
};

// Delete handler
const deleteHandler = async (event: APIGatewayProxyEvent, context: Context) => {
  try {
    const imageId = event.pathParameters?.id;
    
    if (!imageId) {
      return badRequestResponse('Image ID is required');
    }

    const metadata = await getDbService().getImageMetadata(imageId);
    
    if (!metadata) {
      return notFoundResponse('Image not found');
    }

    await getS3Service().deleteImage(metadata.s3Key);
    await getDbService().deleteImageMetadata(imageId);

    return successResponse({
      message: 'Image deleted successfully'
    });

  } catch (error: any) {
    console.error('Delete error:', error);
    
    if (error.message.includes('not found')) {
      return notFoundResponse('Image not found');
    }
    
    return internalErrorResponse(`Delete failed: ${error.message}`);
  }
};

// Setup routes
router.addRoute('POST', '/upload', uploadHandler);
router.addRoute('GET', '/image/{id}', retrieveHandler);
router.addRoute('DELETE', '/image/{id}', deleteHandler);

// Main handler
// Export for testing - allows resetting service instances
export const resetServices = (): void => {
  s3Service = undefined as any;
  dbService = undefined as any;
};

export const handler = async (
  event: any,
  context: Context
): Promise<APIGatewayProxyResult> => {
  console.log('Raw Event:', JSON.stringify(event, null, 2));
  
  try {
    // Normalize the event to API Gateway format
    const normalizedEvent = normalizeEvent(event);
    console.log('Normalized Event:', JSON.stringify(normalizedEvent, null, 2));
    
    const response = await router.route(normalizedEvent, context);
    console.log('Response:', JSON.stringify(response, null, 2));
    return response;
  } catch (error: any) {
    console.error('Handler error:', error);
    return internalErrorResponse('Internal server error');
  }
};
