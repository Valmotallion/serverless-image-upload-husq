import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, GetCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { ImageMetadata } from '../types';

export class DbService {
  private docClient: DynamoDBDocumentClient;
  private tableName: string;

  constructor(tableName?: string) {
    const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
    this.docClient = DynamoDBDocumentClient.from(client);
    this.tableName = tableName || process.env.IMAGES_TABLE_NAME || '';
  }

  async saveImageMetadata(imageId: string, s3Key: string): Promise<void> {
    const metadata: ImageMetadata = {
      imageId,
      s3Key,
      createdAt: new Date().toISOString(),
      ttl: Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60) // 30 days TTL
    };

    const command = new PutCommand({
      TableName: this.tableName,
      Item: metadata
    });

    await this.docClient.send(command);
  }

  async getImageMetadata(imageId: string): Promise<ImageMetadata | null> {
    const command = new GetCommand({
      TableName: this.tableName,
      Key: { imageId }
    });

    const result = await this.docClient.send(command);
    return result.Item as ImageMetadata || null;
  }

  async deleteImageMetadata(imageId: string): Promise<void> {
    const command = new DeleteCommand({
      TableName: this.tableName,
      Key: { imageId }
    });

    await this.docClient.send(command);
  }
}
