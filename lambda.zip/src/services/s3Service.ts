import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { v4 as uuidv4 } from 'uuid';

export class S3Service {
  private s3Client: S3Client;
  private bucketName: string;

  constructor(bucketName?: string) {
    this.s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });
    this.bucketName = bucketName || process.env.IMAGES_BUCKET_NAME || '';
  }

  async uploadImage(imageBuffer: Buffer, contentType: string): Promise<string> {
    const s3Key = `images/${uuidv4()}.${this.getFileExtension(contentType)}`;
    
    const command = new PutObjectCommand({
      Bucket: this.bucketName,
      Key: s3Key,
      Body: imageBuffer,
      ContentType: contentType,
      ServerSideEncryption: 'AES256'
    });

    await this.s3Client.send(command);
    return s3Key;
  }

  async getImage(s3Key: string): Promise<Buffer> {
    const command = new GetObjectCommand({
      Bucket: this.bucketName,
      Key: s3Key
    });

    try {
      const response = await this.s3Client.send(command);
      if (!response.Body) {
        throw new Error('No image data found');
      }
      
      const chunks: Uint8Array[] = [];
      const stream = response.Body as any;
      
      for await (const chunk of stream) {
        chunks.push(chunk);
      }
      
      return Buffer.concat(chunks);
    } catch (error: any) {
      if (error.name === 'NoSuchKey') {
        throw new Error('Image not found in S3');
      }
      throw error;
    }
  }

  async deleteImage(s3Key: string): Promise<void> {
    const command = new DeleteObjectCommand({
      Bucket: this.bucketName,
      Key: s3Key
    });

    await this.s3Client.send(command);
  }

  private getFileExtension(contentType: string): string {
    const mimeToExt: Record<string, string> = {
      'image/jpeg': 'jpg',
      'image/jpg': 'jpg',
      'image/png': 'png',
      'image/gif': 'gif',
      'image/webp': 'webp',
      'image/bmp': 'bmp'
    };

    return mimeToExt[contentType.toLowerCase()] || 'bin';
  }

  getContentTypeFromKey(s3Key: string): string {
    const extension = s3Key.split('.').pop()?.toLowerCase() || '';
    const extToMime: Record<string, string> = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'webp': 'image/webp',
      'bmp': 'image/bmp'
    };

    return extToMime[extension] || 'application/octet-stream';
  }

  isValidImageType(contentType: string): boolean {
    const validTypes = [
      'image/jpeg',
      'image/jpg', 
      'image/png',
      'image/gif',
      'image/webp',
      'image/bmp'
    ];
    
    return validTypes.includes(contentType.toLowerCase());
  }
}
