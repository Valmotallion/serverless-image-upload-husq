import { APIGatewayProxyEvent, Context } from 'aws-lambda';
import { ApiResponse, RouteHandler } from '../types';
import { 
  successResponse, 
  notFoundResponse, 
  badRequestResponse, 
  internalErrorResponse,
  createdResponse,
  binaryResponse
} from '../utils/response';

export class Router {
  private routes: Map<string, RouteHandler> = new Map();

  addRoute(method: string, path: string, handler: RouteHandler): void {
    const key = `${method.toUpperCase()}:${path}`;
    this.routes.set(key, handler);
  }

  async route(event: APIGatewayProxyEvent, context: Context): Promise<ApiResponse> {
    try {
      const method = event.httpMethod;
      const path = event.path;
      
      // Handle CORS preflight
      if (method === 'OPTIONS') {
        return successResponse('OK');
      }

      // Route matching with parameter extraction
      const handler = this.findHandler(method, path);
      
      if (!handler) {
        return notFoundResponse(`Route not found: ${method} ${path}`);
      }

      return await handler(event, context);
    } catch (error: any) {
      console.error('Router error:', error);
      return internalErrorResponse(error.message);
    }
  }

  private findHandler(method: string, path: string): RouteHandler | null {
    // Direct match first
    const directKey = `${method.toUpperCase()}:${path}`;
    if (this.routes.has(directKey)) {
      return this.routes.get(directKey)!;
    }

    // Pattern matching for parameterized routes
    for (const [routeKey, handler] of this.routes.entries()) {
      const [routeMethod, routePath] = routeKey.split(':');
      
      if (routeMethod !== method.toUpperCase()) {
        continue;
      }

      const pathPattern = routePath.replace(/\{[^}]+\}/g, '([^/]+)');
      const regex = new RegExp(`^${pathPattern}$`);
      
      if (regex.test(path)) {
        return handler;
      }
    }

    return null;
  }

  extractPathParameters(routePath: string, actualPath: string): Record<string, string> {
    const routeSegments = routePath.split('/');
    const pathSegments = actualPath.split('/');
    const params: Record<string, string> = {};

    for (let i = 0; i < routeSegments.length; i++) {
      const segment = routeSegments[i];
      if (segment.startsWith('{') && segment.endsWith('}')) {
        const paramName = segment.slice(1, -1);
        params[paramName] = pathSegments[i];
      }
    }

    return params;
  }
}
