export interface ImageMetadata {
  imageId: string;
  s3Key: string;
  createdAt: string;
  ttl?: number;
}

export interface UploadResponse {
  imageId: string;
  accessLink: string;
  message: string;
}

export interface ApiResponse {
  statusCode: number;
  headers: Record<string, string>;
  body: string;
  isBase64Encoded?: boolean;
}

export interface RouteHandler {
  (event: any, context: any): Promise<ApiResponse>;
}
