import { APIGatewayProxyEvent } from 'aws-lambda';
import { resolveBaseUrl, generateImageUrl } from '../src/utils/urlUtils';

describe('URL Utils', () => {
  let mockEvent: Partial<APIGatewayProxyEvent>;

  beforeEach(() => {
    // Clear environment variables before each test
    delete process.env.BASE_URL;
    
    mockEvent = {
      requestContext: {
        domainName: 'api.example.com',
        stage: 'dev',
        requestId: 'test-request',
        identity: {} as any,
        httpMethod: 'POST',
        path: '/upload',
        protocol: 'HTTP/1.1',
        requestTime: '01/Jan/2023:00:00:00 +0000',
        requestTimeEpoch: 1672531200,
        resourceId: 'test',
        resourcePath: '/upload',
        accountId: '123456789',
        apiId: 'test-api',
        authorizer: null as any
      }
    } as APIGatewayProxyEvent;
  });

  describe('resolveBaseUrl', () => {
    it('should use BASE_URL environment variable when set', () => {
      process.env.BASE_URL = 'https://my-custom-domain.com';
      
      const result = resolveBaseUrl(mockEvent as APIGatewayProxyEvent);
      
      expect(result).toBe('https://my-custom-domain.com');
    });

    it('should remove trailing slash from BASE_URL environment variable', () => {
      process.env.BASE_URL = 'https://my-custom-domain.com/';
      
      const result = resolveBaseUrl(mockEvent as APIGatewayProxyEvent);
      
      expect(result).toBe('https://my-custom-domain.com');
    });

    it('should derive URL from API Gateway event context when BASE_URL not set', () => {
      const result = resolveBaseUrl(mockEvent as APIGatewayProxyEvent);
      
      expect(result).toBe('https://api.example.com/dev');
    });

    it('should handle Lambda Function URL format', () => {
      mockEvent.requestContext!.domainName = 'abc123.lambda-url.us-east-1.on.aws';
      
      const result = resolveBaseUrl(mockEvent as APIGatewayProxyEvent);
      
      expect(result).toBe('https://abc123.lambda-url.us-east-1.on.aws');
    });

    it('should handle API Gateway custom domain without stage', () => {
      mockEvent.requestContext!.domainName = 'api.mydomain.com';
      mockEvent.requestContext!.stage = 'prod';
      
      const result = resolveBaseUrl(mockEvent as APIGatewayProxyEvent);
      
      expect(result).toBe('https://api.mydomain.com/prod');
    });
  });

  describe('generateImageUrl', () => {
    it('should generate correct URL with environment variable', () => {
      process.env.BASE_URL = 'https://my-api.com';
      const imageId = 'test-image-123';
      
      const result = generateImageUrl(mockEvent as APIGatewayProxyEvent, imageId);
      
      expect(result).toBe('https://my-api.com/image/test-image-123');
    });

    it('should generate correct URL from event context', () => {
      const imageId = 'test-image-456';
      
      const result = generateImageUrl(mockEvent as APIGatewayProxyEvent, imageId);
      
      expect(result).toBe('https://api.example.com/dev/image/test-image-456');
    });

    it('should work with Lambda Function URL format', () => {
      mockEvent.requestContext!.domainName = 'xyz789.lambda-url.eu-west-1.on.aws';
      const imageId = 'lambda-image-789';
      
      const result = generateImageUrl(mockEvent as APIGatewayProxyEvent, imageId);
      
      expect(result).toBe('https://xyz789.lambda-url.eu-west-1.on.aws/image/lambda-image-789');
    });
  });
});
