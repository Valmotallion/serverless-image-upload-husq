import { Router } from '../src/services/router';
import { APIGatewayProxyEvent, Context } from 'aws-lambda';

describe('Router', () => {
  let router: Router;
  let mockContext: Context;

  beforeEach(() => {
    router = new Router();
    mockContext = {} as Context;
  });

  const createEvent = (method: string, path: string): APIGatewayProxyEvent => ({
    httpMethod: method,
    path,
    pathParameters: null,
    queryStringParameters: null,
    headers: {},
    multiValueHeaders: {},
    body: null,
    isBase64Encoded: false,
    requestContext: {
      domainName: 'api.example.com',
      stage: 'dev',
      requestId: 'test-request',
      identity: {} as any,
      httpMethod: method,
      path,
      protocol: 'HTTP/1.1',
      requestTime: '01/Jan/2023:00:00:00 +0000',
      requestTimeEpoch: 1672531200,
      resourceId: 'test',
      resourcePath: path,
      accountId: '123456789',
      apiId: 'test-api',
      authorizer: null as any
    },
    resource: path,
    stageVariables: null,
    multiValueQueryStringParameters: null
  });

  it('should handle CORS OPTIONS requests', async () => {
    const event = createEvent('OPTIONS', '/upload');
    const result = await router.route(event, mockContext);

    expect(result.statusCode).toBe(200);
    expect(result.headers['Access-Control-Allow-Origin']).toBe('*');
  });

  it('should route to correct handler for exact match', async () => {
    const mockHandler = jest.fn().mockResolvedValue({
      statusCode: 200,
      body: 'success',
      headers: {}
    });

    router.addRoute('POST', '/upload', mockHandler);

    const event = createEvent('POST', '/upload');
    await router.route(event, mockContext);

    expect(mockHandler).toHaveBeenCalledWith(event, mockContext);
  });

  it('should route to parameterized routes', async () => {
    const mockHandler = jest.fn().mockResolvedValue({
      statusCode: 200,
      body: 'success',
      headers: {}
    });

    router.addRoute('GET', '/image/{id}', mockHandler);

    const event = createEvent('GET', '/image/test-123');
    await router.route(event, mockContext);

    expect(mockHandler).toHaveBeenCalledWith(event, mockContext);
  });

  it('should return 404 for unknown routes', async () => {
    const event = createEvent('GET', '/unknown');
    const result = await router.route(event, mockContext);

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Route not found');
  });

  it('should handle router errors gracefully', async () => {
    const mockHandler = jest.fn().mockRejectedValue(new Error('Handler error'));
    router.addRoute('POST', '/upload', mockHandler);

    const event = createEvent('POST', '/upload');
    const result = await router.route(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Handler error');
  });

  it('should extract path parameters correctly', async () => {
    const params = router.extractPathParameters('/image/{id}', '/image/test-123');
    expect(params).toEqual({ id: 'test-123' });

    const multiParams = router.extractPathParameters('/user/{userId}/image/{imageId}', '/user/user-456/image/img-789');
    expect(multiParams).toEqual({ userId: 'user-456', imageId: 'img-789' });
  });
});
