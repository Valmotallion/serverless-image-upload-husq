import { APIGatewayProxyEvent, Context } from 'aws-lambda';
import { handler, resetServices } from '../src/handlers/lambda';
import { S3Service } from '../src/services/s3Service';
import { DbService } from '../src/services/dbService';

// Mock the services
jest.mock('../src/services/s3Service');
jest.mock('../src/services/dbService');

const mockS3Service = S3Service as jest.MockedClass<typeof S3Service>;
const mockDbService = DbService as jest.MockedClass<typeof DbService>;

describe('Lambda Handler - Delete', () => {
  let mockContext: Context;

  beforeEach(() => {
    jest.clearAllMocks();
    resetServices(); // Reset service instances to ensure mocks are applied
    mockContext = {} as Context;
    
    // Setup default mocks
    mockS3Service.prototype.deleteImage = jest.fn();
    mockDbService.prototype.getImageMetadata = jest.fn();
    mockDbService.prototype.deleteImageMetadata = jest.fn();
  });

  const createDeleteEvent = (imageId: string): APIGatewayProxyEvent => ({
    httpMethod: 'DELETE',
    path: `/image/${imageId}`,
    pathParameters: { id: imageId },
    queryStringParameters: null,
    headers: {},
    multiValueHeaders: {},
    body: null,
    isBase64Encoded: false,
    requestContext: {
      domainName: 'api.example.com',
      stage: 'dev',
      requestId: 'test-request',
      identity: {} as any,
      httpMethod: 'DELETE',
      path: `/image/${imageId}`,
      protocol: 'HTTP/1.1',
      requestTime: '01/Jan/2023:00:00:00 +0000',
      requestTimeEpoch: 1672531200,
      resourceId: 'test',
      resourcePath: '/image/{id}',
      accountId: '123456789',
      apiId: 'test-api',
      authorizer: null as any
    },
    resource: '/image/{id}',
    stageVariables: null,
    multiValueQueryStringParameters: null
  });

  it('should delete image successfully', async () => {
    const mockImageId = 'test-image-id';
    const mockS3Key = 'images/test-uuid.png';
    const mockMetadata = {
      imageId: mockImageId,
      s3Key: mockS3Key,
      createdAt: '2023-01-01T00:00:00.000Z'
    };

    mockDbService.prototype.getImageMetadata.mockResolvedValue(mockMetadata);
    mockS3Service.prototype.deleteImage.mockResolvedValue();
    mockDbService.prototype.deleteImageMetadata.mockResolvedValue();

    const event = createDeleteEvent(mockImageId);
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.message).toBe('Image deleted successfully');

    expect(mockDbService.prototype.getImageMetadata).toHaveBeenCalledWith(mockImageId);
    expect(mockS3Service.prototype.deleteImage).toHaveBeenCalledWith(mockS3Key);
    expect(mockDbService.prototype.deleteImageMetadata).toHaveBeenCalledWith(mockImageId);
  });

  it('should return 404 when image not found', async () => {
    mockDbService.prototype.getImageMetadata.mockResolvedValue(null);

    const event = createDeleteEvent('nonexistent-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Image not found');
  });

  it('should return 400 when image ID is missing', async () => {
    const event = createDeleteEvent('test-id');
    event.pathParameters = null;

    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Image ID is required');
  });

  it('should handle S3 deletion errors', async () => {
    const mockMetadata = {
      imageId: 'test-id',
      s3Key: 'images/test.png',
      createdAt: '2023-01-01T00:00:00.000Z'
    };

    mockDbService.prototype.getImageMetadata.mockResolvedValue(mockMetadata);
    mockS3Service.prototype.deleteImage.mockRejectedValue(new Error('S3 delete failed'));

    const event = createDeleteEvent('test-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Delete failed');
  });

  it('should handle database deletion errors', async () => {
    const mockMetadata = {
      imageId: 'test-id',
      s3Key: 'images/test.png',
      createdAt: '2023-01-01T00:00:00.000Z'
    };

    mockDbService.prototype.getImageMetadata.mockResolvedValue(mockMetadata);
    mockS3Service.prototype.deleteImage.mockResolvedValue();
    mockDbService.prototype.deleteImageMetadata.mockRejectedValue(new Error('DB delete failed'));

    const event = createDeleteEvent('test-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Delete failed');
  });

  it('should handle S3 errors that don\'t contain "not found"', async () => {
    const mockMetadata = {
      imageId: 'test-id',
      s3Key: 'images/test.png',
      createdAt: '2023-01-01T00:00:00.000Z'
    };

    mockDbService.prototype.getImageMetadata.mockResolvedValue(mockMetadata);
    mockS3Service.prototype.deleteImage.mockRejectedValue(new Error('S3 connection timeout'));

    const event = createDeleteEvent('test-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Delete failed');
    expect(body.error).toContain('S3 connection timeout');
  });
});
