import { APIGatewayProxyEvent, Context } from 'aws-lambda';
import { handler, resetServices } from '../src/handlers/lambda';
import { S3Service } from '../src/services/s3Service';
import { DbService } from '../src/services/dbService';

// Mock the services
jest.mock('../src/services/s3Service');
jest.mock('../src/services/dbService');

const mockS3Service = S3Service as jest.MockedClass<typeof S3Service>;
const mockDbService = DbService as jest.MockedClass<typeof DbService>;

describe('Lambda Handler - Upload', () => {
  let mockContext: Context;

  beforeEach(() => {
    jest.clearAllMocks();
    resetServices(); // Reset service instances to allow mocking
    mockContext = {} as Context;
    
    // Setup default mocks
    mockS3Service.prototype.uploadImage = jest.fn();
    mockDbService.prototype.saveImageMetadata = jest.fn();
  });

  const createUploadEvent = (body: string, contentType: string = 'image/png', isBase64: boolean = false): APIGatewayProxyEvent => ({
    httpMethod: 'POST',
    path: '/upload',
    pathParameters: null,
    queryStringParameters: null,
    headers: {
      'Content-Type': contentType
    },
    multiValueHeaders: {},
    body,
    isBase64Encoded: isBase64,
    requestContext: {
      domainName: 'api.example.com',
      stage: 'dev',
      requestId: 'test-request',
      identity: {} as any,
      httpMethod: 'POST',
      path: '/upload',
      protocol: 'HTTP/1.1',
      requestTime: '01/Jan/2023:00:00:00 +0000',
      requestTimeEpoch: 1672531200,
      resourceId: 'test',
      resourcePath: '/upload',
      accountId: '123456789',
      apiId: 'test-api',
      authorizer: null as any
    },
    resource: '/upload',
    stageVariables: null,
    multiValueQueryStringParameters: null
  });

  it('should upload image successfully', async () => {
    const mockImageData = Buffer.from('fake-image-data').toString('base64');
    const mockS3Key = 'images/test-uuid.png';
    
    mockS3Service.prototype.uploadImage.mockResolvedValue(mockS3Key);
    mockDbService.prototype.saveImageMetadata.mockResolvedValue();

    const event = createUploadEvent(mockImageData, 'image/png', true);
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(201);
    const body = JSON.parse(result.body);
    expect(body.imageId).toBeDefined();
    expect(body.url).toContain('/image/');
    expect(body.url).toContain('https://api.example.com/dev/image/');
    expect(body.message).toBe('Image uploaded successfully');
    
    expect(mockS3Service.prototype.uploadImage).toHaveBeenCalledWith(
      expect.any(Buffer),
      'image/png'
    );
    expect(mockDbService.prototype.saveImageMetadata).toHaveBeenCalledWith(
      expect.any(String),
      mockS3Key
    );
  });

  it('should use BASE_URL environment variable when available', async () => {
    process.env.BASE_URL = 'https://my-custom-domain.com';
    
    const mockImageData = Buffer.from('fake-image-data').toString('base64');
    const mockS3Key = 'images/test-uuid.png';
    
    mockS3Service.prototype.uploadImage.mockResolvedValue(mockS3Key);
    mockDbService.prototype.saveImageMetadata.mockResolvedValue();

    const event = createUploadEvent(mockImageData, 'image/png', true);
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(201);
    const body = JSON.parse(result.body);
    expect(body.url).toContain('https://my-custom-domain.com/image/');
    
    // Clean up
    delete process.env.BASE_URL;
  });

  it('should reject non-image content types', async () => {
    const event = createUploadEvent('some-data', 'text/plain');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Content-Type must be an image type');
  });

  it('should reject empty body', async () => {
    const event = createUploadEvent('', 'image/png');
    event.body = null;
    
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('No image data provided');
  });

  it('should handle upload service errors', async () => {
    mockS3Service.prototype.uploadImage.mockRejectedValue(new Error('S3 upload failed'));

    const event = createUploadEvent(Buffer.from('fake-image-data').toString('base64'), 'image/png', true);
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Upload failed');
  });

  it('should handle database save errors', async () => {
    mockS3Service.prototype.uploadImage.mockResolvedValue('images/test.png');
    mockDbService.prototype.saveImageMetadata.mockRejectedValue(new Error('DB save failed'));

    const event = createUploadEvent(Buffer.from('fake-image-data').toString('base64'), 'image/png', true);
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Upload failed');
  });

  it('should reject images larger than 10MB', async () => {
    // Create a buffer larger than 10MB (10 * 1024 * 1024 = 10485760 bytes)
    const largeImageData = Buffer.alloc(10485761, 'x').toString('base64'); // 10MB + 1 byte
    
    const event = createUploadEvent(largeImageData, 'image/png', true);
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Image size must be less than 10MB');
  });

  it('should handle case-insensitive content-type header', async () => {
    const mockImageData = Buffer.from('fake-image-data').toString('base64');
    
    mockS3Service.prototype.uploadImage.mockResolvedValue('images/test.png');
    mockDbService.prototype.saveImageMetadata.mockResolvedValue();

    const event = createUploadEvent(mockImageData, '', true);
    event.headers['content-type'] = 'image/jpeg'; // lowercase header

    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(201);
    const body = JSON.parse(result.body);
    expect(body.imageId).toBeDefined();
  });

  it('should handle binary (non-base64) image data', async () => {
    const mockImageData = 'fake-image-data';
    
    mockS3Service.prototype.uploadImage.mockResolvedValue('images/test.png');
    mockDbService.prototype.saveImageMetadata.mockResolvedValue();

    const event = createUploadEvent(mockImageData, 'image/png', false); // isBase64 = false

    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(201);
    const body = JSON.parse(result.body);
    expect(body.imageId).toBeDefined();
  });
});
