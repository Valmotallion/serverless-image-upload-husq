import { mockClient } from 'aws-sdk-client-mock';
import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { S3Service } from '../src/services/s3Service';

const s3Mock = mockClient(S3Client);

describe('S3Service', () => {
  let s3Service: S3Service;

  beforeEach(() => {
    s3Mock.reset();
    s3Service = new S3Service('test-bucket');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('constructor', () => {
    it('should use provided bucket name', () => {
      const service = new S3Service('custom-bucket');
      expect(service).toBeDefined();
    });

    it('should use environment variable when no bucket name provided', () => {
      const originalEnv = process.env.IMAGES_BUCKET_NAME;
      process.env.IMAGES_BUCKET_NAME = 'env-bucket';
      
      const service = new S3Service();
      expect(service).toBeDefined();
      
      // Restore original environment
      if (originalEnv) {
        process.env.IMAGES_BUCKET_NAME = originalEnv;
      } else {
        delete process.env.IMAGES_BUCKET_NAME;
      }
    });

    it('should use empty string when no bucket name and no env var', () => {
      const originalEnv = process.env.IMAGES_BUCKET_NAME;
      delete process.env.IMAGES_BUCKET_NAME;
      
      const service = new S3Service();
      expect(service).toBeDefined();
      
      // Restore original environment
      if (originalEnv) {
        process.env.IMAGES_BUCKET_NAME = originalEnv;
      }
    });
  });

  describe('uploadImage', () => {
    it('should upload image successfully', async () => {
      const mockBuffer = Buffer.from('fake-image-data');
      const contentType = 'image/png';

      s3Mock.on(PutObjectCommand).resolves({});

      const result = await s3Service.uploadImage(mockBuffer, contentType);

      expect(result).toMatch(/^images\/[a-f0-9-]+\.png$/);
      expect(s3Mock.commandCalls(PutObjectCommand)).toHaveLength(1);
      
      const putCall = s3Mock.commandCalls(PutObjectCommand)[0];
      expect(putCall.args[0].input).toMatchObject({
        Bucket: 'test-bucket',
        Body: mockBuffer,
        ContentType: contentType,
        ServerSideEncryption: 'AES256'
      });
    });

    it('should handle different image types', async () => {
      const mockBuffer = Buffer.from('fake-image-data');
      s3Mock.on(PutObjectCommand).resolves({});

      const jpegResult = await s3Service.uploadImage(mockBuffer, 'image/jpeg');
      const gifResult = await s3Service.uploadImage(mockBuffer, 'image/gif');

      expect(jpegResult).toMatch(/\.jpg$/);
      expect(gifResult).toMatch(/\.gif$/);
    });
  });

  describe('getImage', () => {
    it('should retrieve image successfully', async () => {
      const mockBuffer = Buffer.from('fake-image-data');
      const mockStream = {
        async *[Symbol.asyncIterator]() {
          yield mockBuffer;
        }
      } as any;

      s3Mock.on(GetObjectCommand).resolves({
        Body: mockStream
      });

      const result = await s3Service.getImage('images/test.png');

      expect(result).toEqual(mockBuffer);
      expect(s3Mock.commandCalls(GetObjectCommand)).toHaveLength(1);
    });

    it('should throw error when image not found', async () => {
      const error = new Error('NoSuchKey');
      error.name = 'NoSuchKey';
      s3Mock.on(GetObjectCommand).rejects(error);

      await expect(s3Service.getImage('images/nonexistent.png'))
        .rejects.toThrow('Image not found in S3');
    });

    it('should throw error when no body returned', async () => {
      s3Mock.on(GetObjectCommand).resolves({
        Body: undefined
      });

      await expect(s3Service.getImage('images/test.png'))
        .rejects.toThrow('No image data found');
    });
  });

  describe('deleteImage', () => {
    it('should delete image successfully', async () => {
      s3Mock.on(DeleteObjectCommand).resolves({});

      await s3Service.deleteImage('images/test.png');

      expect(s3Mock.commandCalls(DeleteObjectCommand)).toHaveLength(1);
      const deleteCall = s3Mock.commandCalls(DeleteObjectCommand)[0];
      expect(deleteCall.args[0].input).toMatchObject({
        Bucket: 'test-bucket',
        Key: 'images/test.png'
      });
    });
  });

  describe('getContentTypeFromKey', () => {
    it('should return correct content type for various extensions', () => {
      expect(s3Service.getContentTypeFromKey('images/test.jpg')).toBe('image/jpeg');
      expect(s3Service.getContentTypeFromKey('images/test.png')).toBe('image/png');
      expect(s3Service.getContentTypeFromKey('images/test.gif')).toBe('image/gif');
      expect(s3Service.getContentTypeFromKey('images/test.webp')).toBe('image/webp');
      expect(s3Service.getContentTypeFromKey('images/test.unknown')).toBe('application/octet-stream');
    });
  });

  describe('isValidImageType', () => {
    it('should validate image types correctly', () => {
      expect(s3Service.isValidImageType('image/png')).toBe(true);
      expect(s3Service.isValidImageType('image/jpeg')).toBe(true);
      expect(s3Service.isValidImageType('image/gif')).toBe(true);
      expect(s3Service.isValidImageType('text/plain')).toBe(false);
      expect(s3Service.isValidImageType('application/pdf')).toBe(false);
    });
  });
});
