import {
  createResponse,
  successResponse,
  createdResponse,
  notFoundResponse,
  badRequestResponse,
  internalErrorResponse,
  binaryResponse
} from '../src/utils/response';

describe('Response Utils', () => {
  describe('createResponse', () => {
    it('should create response with default headers', () => {
      const response = createResponse(200, { message: 'test' });
      
      expect(response.statusCode).toBe(200);
      expect(response.body).toBe('{"message":"test"}');
      expect(response.headers['Content-Type']).toBe('application/json');
      expect(response.headers['Access-Control-Allow-Origin']).toBe('*');
      expect(response.isBase64Encoded).toBe(false);
    });

    it('should create response with custom headers', () => {
      const customHeaders = { 'Custom-Header': 'custom-value' };
      const response = createResponse(200, 'test', customHeaders, true);
      
      expect(response.statusCode).toBe(200);
      expect(response.body).toBe('test');
      expect(response.headers['Custom-Header']).toBe('custom-value');
      expect(response.isBase64Encoded).toBe(true);
    });

    it('should handle string body without JSON stringifying', () => {
      const response = createResponse(200, 'plain text');
      
      expect(response.body).toBe('plain text');
    });
  });

  describe('successResponse', () => {
    it('should return 200 status', () => {
      const response = successResponse({ success: true });
      
      expect(response.statusCode).toBe(200);
      expect(JSON.parse(response.body)).toEqual({ success: true });
    });

    it('should accept custom headers', () => {
      const response = successResponse({ success: true }, { 'Custom': 'header' });
      
      expect(response.headers['Custom']).toBe('header');
    });
  });

  describe('createdResponse', () => {
    it('should return 201 status', () => {
      const response = createdResponse({ created: true });
      
      expect(response.statusCode).toBe(201);
      expect(JSON.parse(response.body)).toEqual({ created: true });
    });
  });

  describe('notFoundResponse', () => {
    it('should return 404 status with default message', () => {
      const response = notFoundResponse();
      
      expect(response.statusCode).toBe(404);
      expect(JSON.parse(response.body)).toEqual({ error: 'Resource not found' });
    });

    it('should return 404 status with custom message', () => {
      const response = notFoundResponse('Custom not found');
      
      expect(response.statusCode).toBe(404);
      expect(JSON.parse(response.body)).toEqual({ error: 'Custom not found' });
    });
  });

  describe('badRequestResponse', () => {
    it('should return 400 status', () => {
      const response = badRequestResponse('Bad input');
      
      expect(response.statusCode).toBe(400);
      expect(JSON.parse(response.body)).toEqual({ error: 'Bad input' });
    });
  });

  describe('internalErrorResponse', () => {
    it('should return 500 status with default message', () => {
      const response = internalErrorResponse();
      
      expect(response.statusCode).toBe(500);
      expect(JSON.parse(response.body)).toEqual({ error: 'Internal server error' });
    });

    it('should return 500 status with custom message', () => {
      const response = internalErrorResponse('Custom error');
      
      expect(response.statusCode).toBe(500);
      expect(JSON.parse(response.body)).toEqual({ error: 'Custom error' });
    });
  });

  describe('binaryResponse', () => {
    it('should return binary response with base64 encoding', () => {
      const buffer = Buffer.from('binary data');
      const response = binaryResponse(buffer, 'image/png');
      
      expect(response.statusCode).toBe(200);
      expect(response.headers['Content-Type']).toBe('image/png');
      expect(response.headers['Access-Control-Allow-Origin']).toBe('*');
      expect(response.headers['Cache-Control']).toBe('max-age=3600');
      expect(response.body).toBe(buffer.toString('base64'));
      expect(response.isBase64Encoded).toBe(true);
    });
  });
});
