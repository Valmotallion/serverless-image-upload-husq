import { mockClient } from 'aws-sdk-client-mock';
import { DynamoDBDocumentClient, PutCommand, GetCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { DbService } from '../src/services/dbService';

const dynamoMock = mockClient(DynamoDBDocumentClient);

describe('DbService', () => {
  let dbService: DbService;

  beforeEach(() => {
    dynamoMock.reset();
    dbService = new DbService('test-table');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('constructor', () => {
    it('should use provided table name', () => {
      const service = new DbService('custom-table');
      expect(service).toBeDefined();
    });

    it('should use environment variable when no table name provided', () => {
      const originalEnv = process.env.IMAGES_TABLE_NAME;
      process.env.IMAGES_TABLE_NAME = 'env-table';
      
      const service = new DbService();
      expect(service).toBeDefined();
      
      // Restore original environment
      if (originalEnv) {
        process.env.IMAGES_TABLE_NAME = originalEnv;
      } else {
        delete process.env.IMAGES_TABLE_NAME;
      }
    });

    it('should use empty string when no table name and no env var', () => {
      const originalEnv = process.env.IMAGES_TABLE_NAME;
      delete process.env.IMAGES_TABLE_NAME;
      
      const service = new DbService();
      expect(service).toBeDefined();
      
      // Restore original environment
      if (originalEnv) {
        process.env.IMAGES_TABLE_NAME = originalEnv;
      }
    });
  });

  describe('saveImageMetadata', () => {
    it('should save image metadata successfully', async () => {
      dynamoMock.on(PutCommand).resolves({});

      await dbService.saveImageMetadata('test-id', 'images/test.png');

      expect(dynamoMock.commandCalls(PutCommand)).toHaveLength(1);
      
      const putCall = dynamoMock.commandCalls(PutCommand)[0];
      const item = putCall.args[0].input.Item;
      
      expect(item).toMatchObject({
        imageId: 'test-id',
        s3Key: 'images/test.png'
      });
      expect(item!.createdAt).toBeDefined();
      expect(item!.ttl).toBeDefined();
      expect(typeof item!.ttl).toBe('number');
    });

    it('should handle database errors', async () => {
      dynamoMock.on(PutCommand).rejects(new Error('Database error'));

      await expect(dbService.saveImageMetadata('test-id', 'images/test.png'))
        .rejects.toThrow('Database error');
    });
  });

  describe('getImageMetadata', () => {
    it('should retrieve image metadata successfully', async () => {
      const mockMetadata = {
        imageId: 'test-id',
        s3Key: 'images/test.png',
        createdAt: '2023-01-01T00:00:00.000Z',
        ttl: 1672531200
      };

      dynamoMock.on(GetCommand).resolves({
        Item: mockMetadata
      });

      const result = await dbService.getImageMetadata('test-id');

      expect(result).toEqual(mockMetadata);
      expect(dynamoMock.commandCalls(GetCommand)).toHaveLength(1);
      
      const getCall = dynamoMock.commandCalls(GetCommand)[0];
      expect(getCall.args[0].input).toMatchObject({
        TableName: 'test-table',
        Key: { imageId: 'test-id' }
      });
    });

    it('should return null when item not found', async () => {
      dynamoMock.on(GetCommand).resolves({
        Item: undefined
      });

      const result = await dbService.getImageMetadata('nonexistent-id');

      expect(result).toBeNull();
    });

    it('should handle database errors', async () => {
      dynamoMock.on(GetCommand).rejects(new Error('Database error'));

      await expect(dbService.getImageMetadata('test-id'))
        .rejects.toThrow('Database error');
    });
  });

  describe('deleteImageMetadata', () => {
    it('should delete image metadata successfully', async () => {
      dynamoMock.on(DeleteCommand).resolves({});

      await dbService.deleteImageMetadata('test-id');

      expect(dynamoMock.commandCalls(DeleteCommand)).toHaveLength(1);
      
      const deleteCall = dynamoMock.commandCalls(DeleteCommand)[0];
      expect(deleteCall.args[0].input).toMatchObject({
        TableName: 'test-table',
        Key: { imageId: 'test-id' }
      });
    });

    it('should handle database errors', async () => {
      dynamoMock.on(DeleteCommand).rejects(new Error('Database error'));

      await expect(dbService.deleteImageMetadata('test-id'))
        .rejects.toThrow('Database error');
    });
  });
});
