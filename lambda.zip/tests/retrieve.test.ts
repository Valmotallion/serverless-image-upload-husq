import { APIGatewayProxyEvent, Context } from 'aws-lambda';
import { handler, resetServices } from '../src/handlers/lambda';
import { S3Service } from '../src/services/s3Service';
import { DbService } from '../src/services/dbService';

// Mock the services
jest.mock('../src/services/s3Service');
jest.mock('../src/services/dbService');

const mockS3Service = S3Service as jest.MockedClass<typeof S3Service>;
const mockDbService = DbService as jest.MockedClass<typeof DbService>;

describe('Lambda Handler - Retrieve', () => {
  let mockContext: Context;

  beforeEach(() => {
    jest.clearAllMocks();
    resetServices(); // Reset service instances to ensure mocks are applied
    mockContext = {} as Context;
    
    // Setup default mocks
    mockS3Service.prototype.getImage = jest.fn();
    mockS3Service.prototype.getContentTypeFromKey = jest.fn();
    mockDbService.prototype.getImageMetadata = jest.fn();
  });

  const createRetrieveEvent = (imageId: string): APIGatewayProxyEvent => ({
    httpMethod: 'GET',
    path: `/image/${imageId}`,
    pathParameters: { id: imageId },
    queryStringParameters: null,
    headers: {},
    multiValueHeaders: {},
    body: null,
    isBase64Encoded: false,
    requestContext: {
      domainName: 'api.example.com',
      stage: 'dev',
      requestId: 'test-request',
      identity: {} as any,
      httpMethod: 'GET',
      path: `/image/${imageId}`,
      protocol: 'HTTP/1.1',
      requestTime: '01/Jan/2023:00:00:00 +0000',
      requestTimeEpoch: 1672531200,
      resourceId: 'test',
      resourcePath: '/image/{id}',
      accountId: '123456789',
      apiId: 'test-api',
      authorizer: null as any
    },
    resource: '/image/{id}',
    stageVariables: null,
    multiValueQueryStringParameters: null
  });

  it('should retrieve image successfully', async () => {
    const mockImageId = 'test-image-id';
    const mockS3Key = 'images/test-uuid.png';
    const mockImageBuffer = Buffer.from('fake-image-data');
    const mockMetadata = {
      imageId: mockImageId,
      s3Key: mockS3Key,
      createdAt: '2023-01-01T00:00:00.000Z'
    };

    mockDbService.prototype.getImageMetadata.mockResolvedValue(mockMetadata);
    mockS3Service.prototype.getImage.mockResolvedValue(mockImageBuffer);
    mockS3Service.prototype.getContentTypeFromKey.mockReturnValue('image/png');

    const event = createRetrieveEvent(mockImageId);
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(200);
    expect(result.headers?.['Content-Type']).toBe('image/png');
    expect(result.isBase64Encoded).toBe(true);
    expect(result.body).toBe(mockImageBuffer.toString('base64'));

    expect(mockDbService.prototype.getImageMetadata).toHaveBeenCalledWith(mockImageId);
    expect(mockS3Service.prototype.getImage).toHaveBeenCalledWith(mockS3Key);
    expect(mockS3Service.prototype.getContentTypeFromKey).toHaveBeenCalledWith(mockS3Key);
  });

  it('should return 404 when image metadata not found', async () => {
    mockDbService.prototype.getImageMetadata.mockResolvedValue(null);

    const event = createRetrieveEvent('nonexistent-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Image not found');
  });

  it('should return 400 when image ID is missing', async () => {
    const event = createRetrieveEvent('test-id');
    event.pathParameters = null;

    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Image ID is required');
  });

  it('should handle S3 retrieval errors', async () => {
    const mockMetadata = {
      imageId: 'test-id',
      s3Key: 'images/test.png',
      createdAt: '2023-01-01T00:00:00.000Z'
    };

    mockDbService.prototype.getImageMetadata.mockResolvedValue(mockMetadata);
    mockS3Service.prototype.getImage.mockRejectedValue(new Error('Image not found in S3'));

    const event = createRetrieveEvent('test-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toBe('Image not found');
  });

  it('should handle database retrieval errors', async () => {
    mockDbService.prototype.getImageMetadata.mockRejectedValue(new Error('Database error'));

    const event = createRetrieveEvent('test-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Retrieve failed');
  });

  it('should handle S3 errors that don\'t contain "not found"', async () => {
    const mockMetadata = {
      imageId: 'test-id',
      s3Key: 'images/test.png',
      createdAt: '2023-01-01T00:00:00.000Z'
    };

    mockDbService.prototype.getImageMetadata.mockResolvedValue(mockMetadata);
    mockS3Service.prototype.getImage.mockRejectedValue(new Error('S3 connection timeout'));
    mockS3Service.prototype.getContentTypeFromKey.mockReturnValue('image/png');

    const event = createRetrieveEvent('test-id');
    const result = await handler(event, mockContext);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toContain('Retrieve failed');
    expect(body.error).toContain('S3 connection timeout');
  });
});
